package ADA;

import java.io.*;
import java.util.*;
import java.util.regex.*;

public class Complexitytands {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Enter the path of the Java file to analyze:");
            String filePath = scanner.nextLine();

            try {
                String code = readFile(filePath);

                System.out.println("\nAnalyzing Program...");
                System.out.println("\nCode:\n" + code);

                analyzeTimeComplexity(code);
                analyzeSpaceComplexity(code);

            } catch (IOException e) {
                System.out.println("Error reading file: " + e.getMessage());
            }
        }
    }

    private static String readFile(String filePath) throws IOException {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        }
        return content.toString();
    }

    private static void analyzeTimeComplexity(String code) {
        int loopCount = 0;
        int nestedLoopCount = 0;
        int recursionCount = 0;

        Matcher forMatcher = Pattern.compile("\\bfor\\s*\\(.*?;.*?;.*?\\)").matcher(code);
        Matcher whileMatcher = Pattern.compile("\\bwhile\\s*\\(.*?\\)").matcher(code);
        Matcher recursionMatcher = Pattern.compile("\\b([a-zA-Z0-9_]+)\\s*\\(.*?\\)\\s*\\{").matcher(code);

        while (forMatcher.find()) loopCount++;
        while (whileMatcher.find()) loopCount++;

        nestedLoopCount = detectNestedLoops(code);

        while (recursionMatcher.find()) {
            String methodName = recursionMatcher.group(1);
            Pattern recursiveCallPattern = Pattern.compile("\\b" + methodName + "\\s*\\(");
            Matcher recursiveCalls = recursiveCallPattern.matcher(code);
            
            while (recursiveCalls.find()) {
                recursionCount++;
            }
        }

        System.out.println("\n--- Time Complexity Analysis ---");
        if (recursionCount > 0) {
            System.out.println("Detected Recursion: " + recursionCount);
            System.out.println("Estimated Time Complexity: O(2^n) (Exponential)");
        } else if (nestedLoopCount > 0) {
            System.out.println("Nested Loops: " + nestedLoopCount);
            System.out.println("Estimated Time Complexity: O(n^2) or higher (Quadratic or more)");
        } else if (loopCount > 0) {
            System.out.println("Detected Loops: " + loopCount);
            System.out.println("Estimated Time Complexity: O(n) (Linear)");
        } else {
            System.out.println("Estimated Time Complexity: O(1) (Constant)");
        }
    }

    private static int detectNestedLoops(String code) {
        int nestedLoopCount = 0;
        String[] lines = code.split("\\n");

        Stack<Boolean> loopStack = new Stack<>();

        for (String line : lines) {
            line = line.trim();
            if (line.startsWith("for") || line.startsWith("while")) {
                loopStack.push(true);
            }
            
            if (line.contains("}")) {
                if (!loopStack.isEmpty()) {
                    loopStack.pop();
                }
            }
            
            if (loopStack.size() > 1) {
                nestedLoopCount++;
            }
        }

        return nestedLoopCount;
    }

    private static void analyzeSpaceComplexity(String code) {
        int variableCount = 0;
        int arrayCount = 0;
        int collectionCount = 0;

        Matcher varMatcher = Pattern.compile("\\b(int|double|float|long|String|char|boolean)\\s+([a-zA-Z0-9_,\\s]+)").matcher(code);
        Matcher arrayMatcher = Pattern.compile("\\b(int|double|float|long|String|char)\\s*\\[.*?\\]").matcher(code);
        Matcher collectionMatcher = Pattern.compile("new\\s+(ArrayList|HashMap|LinkedList|HashSet|TreeMap|TreeSet)").matcher(code);

        while (varMatcher.find()) {
            String[] vars = varMatcher.group(2).split(",");
            variableCount += vars.length;
        }

        while (arrayMatcher.find()) arrayCount++;
        while (collectionMatcher.find()) collectionCount++;

        System.out.println("\n--- Space Complexity Analysis ---");
        System.out.println("Variables: " + variableCount);
        System.out.println("Arrays: " + arrayCount);
        System.out.println("Collections: " + collectionCount);

        String complexity = "O(1) (Constant Space)";

        if (arrayCount > 0 || collectionCount > 0) {
            complexity = "O(n) or higher (Dynamic Allocation)";
        } else if (variableCount > 10) {
            complexity = "O(n) (Linear Space)";
        }

        System.out.println("Estimated Space Complexity: " + complexity);
    }
}


